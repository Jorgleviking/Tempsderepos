package com.example.tempsderepos

import android.content.Intent
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.Environment
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.max

private const val DAYS = 8 // Friday -> Thursday + following Friday
private const val WORK_DAYS = 7
private const val SLOTS = 96
private const val SLOT_MINUTES = 15

private fun dayNames() = listOf("Vendredi", "Samedi", "Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi +1")

private data class WeekInfo(val number: Int, val year: Int, val firstFriday: Calendar, val fileBase: String)

private fun weekInfo(date: Calendar = Calendar.getInstance()): WeekInfo {
    val d = date.clone() as Calendar
    d.set(Calendar.HOUR_OF_DAY, 0); d.set(Calendar.MINUTE, 0); d.set(Calendar.SECOND, 0); d.set(Calendar.MILLISECOND, 0)
    val year = d.get(Calendar.YEAR)
    val first = Calendar.getInstance().apply {
        clear(); set(year, Calendar.JANUARY, 1)
        while (get(Calendar.DAY_OF_WEEK) != Calendar.FRIDAY) add(Calendar.DAY_OF_MONTH, 1)
    }
    val actualFirst = if (d.before(first)) Calendar.getInstance().apply {
        clear(); set(year - 1, Calendar.JANUARY, 1)
        while (get(Calendar.DAY_OF_WEEK) != Calendar.FRIDAY) add(Calendar.DAY_OF_MONTH, 1)
        // first Friday of previous year
    } else first
    val diffDays = ((d.timeInMillis - actualFirst.timeInMillis) / 86_400_000L).toInt()
    val n = diffDays / 7 + 1
    val y = actualFirst.get(Calendar.YEAR)
    return WeekInfo(n, y, actualFirst, "Semaine_${n.toString().padStart(2, '0')}_$y")
}

private fun formatDuration(minutes: Int): String = "${minutes / 60}h${(minutes % 60).toString().padStart(2, '0')}"

private data class Summary(val worked: Int, val restFrom13: Int, val worked24: Int, val rest24: Int)

private fun computeSummary(selected: Set<Pair<Int, Int>>, day: Int): Summary {
    val indices = (0 until SLOTS).filter { selected.contains(day to it) }
    val worked = indices.size * SLOT_MINUTES
    if (indices.isEmpty()) return Summary(0, 0, 0, 0)
    val rests = mutableListOf<Pair<Int, Int>>()
    var prev = indices.first()
    for (i in indices.drop(1)) {
        if (i > prev) rests += prev to i
        prev = i
    }
    var rest24 = 0
    var rest13 = 0
    for ((start, end) in rests) {
        val duration = (end - start) * SLOT_MINUTES
        if (duration >= 120) {
            rest24 += duration
            val start13 = 20 // 13:00, five hours after 08:00
            val overlapStart = max(start, start13)
            if (end > overlapStart) rest13 += (end - overlapStart) * SLOT_MINUTES
        }
    }
    return Summary(worked, rest13, worked, rest24)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TempsDeReposApp() }
    }

    fun sharePdf(person: String, captain: String, signed: Boolean, week: WeekInfo, selected: Set<Pair<Int, Int>>) {
        val dir = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)!!
        val file = File(dir, "${week.fileBase}.pdf")
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
        val c = page.canvas
        val p = Paint().apply { color = android.graphics.Color.BLACK; textSize = 15f; isAntiAlias = true }
        c.drawText("TEMPS DE REPOS", 40f, 45f, p)
        p.textSize = 11f
        c.drawText("Personne : $person", 40f, 70f, p)
        c.drawText("Semaine ${week.number} / ${week.year} — vendredi → jeudi", 40f, 90f, p)
        c.drawText("Nom du fichier : ${week.fileBase}.pdf", 40f, 108f, p)
        c.drawText("Validation définitive : ${if (signed) "OUI" else "NON"}", 40f, 126f, p)
        c.drawText("Capitaine : $captain", 40f, 144f, p)
        var y = 178f
        dayNames().forEachIndexed { d, name ->
            val s = computeSummary(selected, d)
            c.drawText("$name : travaillé ${formatDuration(s.worked)} — repos ≥ 2h ${formatDuration(s.rest24)}", 40f, y, p)
            y += 21f
        }
        val current = computeSummary(selected, 0)
        c.drawText("Depuis 08h00 : travaillé ${formatDuration(current.worked)} — repos depuis 13h00 ≥2h ${formatDuration(current.restFrom13)}", 40f, y + 10f, p)
        c.drawText("24 dernières heures : travaillé ${formatDuration(current.worked24)} — repos ≥2h ${formatDuration(current.rest24)}", 40f, y + 30f, p)
        c.drawText("Une case sélectionnée = temps travaillé. Grille de 15 minutes.", 40f, y + 55f, p)
        doc.finishPage(page)
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }, "Envoyer le rapport PDF"))
    }
}

@Composable
fun TempsDeReposApp() {
    val context = LocalContext.current
    val activity = context as? MainActivity
    val prefs = remember { context.getSharedPreferences("tempsderepos", 0) }
    val names = dayNames()
    val week = remember { weekInfo() }

    var person by remember { mutableStateOf(prefs.getString("person", "") ?: "") }
    var captain by remember { mutableStateOf(prefs.getString("captain", "") ?: "") }
    var day by remember { mutableStateOf(prefs.getInt("day", 0).coerceIn(0, DAYS - 1)) }
    var validated by remember { mutableStateOf(prefs.getBoolean("validated", false)) }
    var signed by remember { mutableStateOf(prefs.getBoolean("signed", false)) }
    var showSignature by remember { mutableStateOf(false) }
    var selected by remember {
        mutableStateOf(buildSet {
            val raw = prefs.getString("selected", "") ?: ""
            raw.split(',').filter { it.isNotBlank() }.forEach { token ->
                val a = token.split(':')
                if (a.size == 2) {
                    val d = a[0].toIntOrNull(); val s = a[1].toIntOrNull()
                    if (d != null && s != null && d in 0 until DAYS && s in 0 until SLOTS) add(d to s)
                }
            }
        })
    }
    var anchor by remember { mutableStateOf<Pair<Int, Int>?>(null) }

    fun save() {
        prefs.edit()
            .putString("person", person)
            .putString("captain", captain)
            .putInt("day", day)
            .putBoolean("validated", validated)
            .putBoolean("signed", signed)
            .putString("selected", selected.sortedWith(compareBy<Pair<Int, Int>> { it.first }.thenBy { it.second }).joinToString(",") { "${it.first}:${it.second}" })
            .apply()
    }

    val summary = computeSummary(selected, day)
    val slots = (0 until SLOTS).map { i ->
        val m = i * SLOT_MINUTES
        String.format(Locale.FRANCE, "%02d:%02d", (8 + m / 60) % 24, m % 60)
    }

    MaterialTheme {
        Column(Modifier.fillMaxSize().background(Color(0xFFF5F7FA))) {
            Row(Modifier.fillMaxWidth().background(Color.White).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("TEMPS DE REPOS", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Semaine ${week.number} / ${week.year} — vendredi → jeudi", color = Color.Gray, fontSize = 12.sp)
                }
                Text("Données conservées", fontSize = 11.sp, color = Color(0xFF2E7D32))
            }

            Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState())) {
                OutlinedTextField(value = person, onValueChange = { if (!validated) { person = it; save() } }, label = { Text("Nom de la personne") }, modifier = Modifier.fillMaxWidth(), enabled = !validated)
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Semaine : ", fontWeight = FontWeight.Bold)
                    Text("${week.number} / ${week.year}")
                }
                Text("Début : ${SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE).format(week.firstFriday.time)} — l'année du fichier est celle du vendredi de début.", fontSize = 11.sp, color = Color.Gray)
                Text("Fichier : ${week.fileBase}.pdf", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(7.dp))

                Row(Modifier.horizontalScroll(rememberScrollState())) {
                    names.forEachIndexed { i, name ->
                        FilterChip(selected = day == i, onClick = { if (!validated) { day = i; anchor = null; save() } }, label = { Text(name) }, modifier = Modifier.padding(end = 5.dp))
                    }
                }
                Spacer(Modifier.height(8.dp))

                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(10.dp)) {
                        Text("${names[day]} — 08:00 → 08:00", fontWeight = FontWeight.Bold)
                        Text("Touchez = heure travaillée. Appui long = sélectionne toute la plage depuis la dernière case sélectionnée.", fontSize = 12.sp, color = Color.Gray)
                        Spacer(Modifier.height(6.dp))
                        Row(Modifier.horizontalScroll(rememberScrollState()).padding(bottom = 6.dp)) {
                            slots.forEachIndexed { i, t ->
                                val key = day to i
                                Box(
                                    Modifier.width(52.dp).height(58.dp).padding(2.dp).clip(RoundedCornerShape(4.dp))
                                        .background(if (selected.contains(key)) Color(0xFF90CAF9) else Color.White)
                                        .border(1.dp, Color.LightGray, RoundedCornerShape(4.dp))
                                        .pointerInput(validated, anchor, selected, day) {
                                            detectTapGestures(
                                                onTap = {
                                                    if (!validated) {
                                                        selected = selected.toMutableSet().apply { if (!add(key)) remove(key) }
                                                        anchor = key
                                                        save()
                                                    }
                                                },
                                                onLongPress = {
                                                    if (!validated) {
                                                        val a = anchor ?: key
                                                        val start = minOf(a.second, i); val end = max(a.second, i)
                                                        val next = selected.toMutableSet()
                                                        for (s in start..end) next.add(day to s)
                                                        selected = next
                                                        anchor = key
                                                        save()
                                                    }
                                                }
                                            )
                                        },
                                    contentAlignment = Alignment.Center
                                ) { Text(t, fontSize = 9.sp) }
                            }
                        }
                    }
                }

                Spacer(Modifier.height(8.dp))
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(10.dp)) {
                        Text("RÉCAPITULATIF — ${names[day]}", fontWeight = FontWeight.Bold)
                        Text("Heures travaillées depuis 08h00 : ${formatDuration(summary.worked)}", fontWeight = FontWeight.SemiBold)
                        Text("Heures de repos depuis 08h00 : ${formatDuration(summary.restFrom13)}  (repos ≥ 2h, compté à partir de 13h00)")
                        Spacer(Modifier.height(3.dp))
                        Text("Heures travaillées sur les 24 dernières heures : ${formatDuration(summary.worked24)}", fontWeight = FontWeight.SemiBold)
                        Text("Heures de repos sur les 24 dernières heures : ${formatDuration(summary.rest24)}  (repos ≥ 2h)")
                    }
                }

                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Signature utilisateur : ", fontWeight = FontWeight.Bold)
                    Text(if (signed) "SIGNÉE" else "Non signée", color = if (signed) Color(0xFF2E7D32) else Color.Gray)
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { showSignature = true }, enabled = !validated) { Text("Signer") }
                }
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(value = captain, onValueChange = { if (!validated) { captain = it; save() } }, label = { Text("Nom du capitaine") }, modifier = Modifier.fillMaxWidth(), enabled = !validated)
                Spacer(Modifier.height(7.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(onClick = { activity?.sharePdf(person, captain, signed, week, selected) }, modifier = Modifier.weight(1f)) { Text("PDF / Mail") }
                    Button(onClick = { validated = true; save() }, enabled = !validated && signed && captain.isNotBlank(), modifier = Modifier.weight(1f)) { Text("VALIDATION DÉFINITIVE") }
                }
                if (validated) Text("🔒 Feuille définitivement validée et verrouillée.", color = Color(0xFFB71C1C), fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
            }
        }

        if (showSignature) AlertDialog(
            onDismissRequest = { showSignature = false },
            title = { Text("Signature électronique") },
            text = { Text("Confirmez la signature pour enregistrer l'accord.") },
            confirmButton = { Button(onClick = { signed = true; showSignature = false; save() }) { Text("Signer") } },
            dismissButton = { TextButton(onClick = { showSignature = false }) { Text("Annuler") } }
        )
    }
}
