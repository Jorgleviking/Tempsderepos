package com.example.tempsderepos

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.os.Bundle
import android.os.Environment
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { TempsDeReposApp() } }

    private fun makePdf(person: String, captain: String, signed: Boolean): File {
        val dir = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)!!
        val file = File(dir, "Tempsderepos_${SimpleDateFormat("yyyyMMdd_HHmm", Locale.FRANCE).format(Date())}.pdf")
        val bmp = Bitmap.createBitmap(595, 842, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp); c.drawColor(android.graphics.Color.WHITE)
        val p = Paint().apply { color = android.graphics.Color.BLACK; textSize = 22f; isAntiAlias = true }
        c.drawText("TEMPS DE REPOS", 40f, 55f, p); p.textSize = 14f
        c.drawText("Personne : $person", 40f, 90f, p)
        c.drawText("Semaine : vendredi 08:00 → vendredi 08:00", 40f, 115f, p)
        c.drawText("Journée : 08:00 → 08:00", 40f, 140f, p)
        c.drawText("Validation définitive : ${if (signed) "OUI" else "NON"}", 40f, 165f, p)
        c.drawText("Capitaine : $captain", 40f, 190f, p)
        c.drawText("Créé le : ${SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE).format(Date())}", 40f, 215f, p)
        c.drawText("Grille de saisie : incréments de 15 minutes", 40f, 255f, p)
        c.drawText("08:00 — 08:15 — 08:30 — 08:45 — … — 07:45", 40f, 280f, p)
        c.drawText("Aucune règle d'heures de repos appliquée dans cette version.", 40f, 320f, p)
        FileOutputStream(file).use { out -> bmp.compress(Bitmap.CompressFormat.PNG, 100, out) }
        return file
    }

    fun sharePdf(person: String, captain: String, signed: Boolean) {
        val f = makePdf(person, captain, signed)
        val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type="application/pdf"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }, "Envoyer le rapport PDF"))
    }
}

@Composable fun TempsDeReposApp() {
    var person by remember { mutableStateOf("") }; var captain by remember { mutableStateOf("") }
    var day by remember { mutableStateOf("Vendredi") }; var validated by remember { mutableStateOf(false) }
    var signed by remember { mutableStateOf(false) }; var showSignature by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf(setOf<Int>()) }
    val days = listOf("Vendredi","Samedi","Dimanche","Lundi","Mardi","Mercredi","Jeudi")
    val slots = (0 until 96).map { i -> val m=i*15; String.format(Locale.FRANCE,"%02d:%02d",(8+m/60)%24,m%60) }
    MaterialTheme {
        Column(Modifier.fillMaxSize().background(Color(0xFFF5F7FA))) {
            Row(Modifier.fillMaxWidth().background(Color.White).padding(14.dp), verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("TEMPS DE REPOS", fontSize=22.sp, fontWeight=FontWeight.Bold); Text("Feuille journalière", color=Color.Gray) }
                Text("Hors connexion", fontSize=12.sp, color=Color(0xFF2E7D32))
            }
            Column(Modifier.padding(12.dp)) {
                OutlinedTextField(person, { if(!validated) person=it }, label={Text("Nom de la personne")}, modifier=Modifier.fillMaxWidth(), enabled=!validated)
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment=Alignment.CenterVertically) { Text("Semaine : ", fontWeight=FontWeight.Bold); Text("Vendredi 08:00 → Vendredi 08:00") }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.horizontalScroll(rememberScrollState())) { days.forEach { d -> FilterChip(selected=day==d,onClick={if(!validated)day=d},label={Text(d)},modifier=Modifier.padding(end=5.dp))) } }
                Spacer(Modifier.height(10.dp))
                Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(10.dp)) {
                    Text("$day — 08:00 → 08:00", fontWeight=FontWeight.Bold)
                    Text("Touchez une case de 15 min pour la sélectionner", fontSize=12.sp, color=Color.Gray)
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(bottom=8.dp)) { slots.forEachIndexed { i,t -> Box(Modifier.width(52.dp).height(58.dp).padding(2.dp).clip(RoundedCornerShape(4.dp)).background(if(selected.contains(i)) Color(0xFF90CAF9) else Color.White).border(1.dp,Color.LightGray,RoundedCornerShape(4.dp)).clickable(enabled=!validated){ selected=selected.toMutableSet().apply{if(!add(i))remove(i)} }, contentAlignment=Alignment.Center){ Text(t, fontSize=9.sp) } } }
                }}
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment=Alignment.CenterVertically) { Text("Signature utilisateur : ",fontWeight=FontWeight.Bold); Text(if(signed)"SIGNÉE" else "Non signée", color=if(signed)Color(0xFF2E7D32) else Color.Gray); Spacer(Modifier.width(8.dp)); Button(onClick={showSignature=true},enabled=!validated){Text("Signer")} }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(captain,{if(!validated)captain=it},label={Text("Nom du capitaine")},modifier=Modifier.fillMaxWidth(),enabled=!validated)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp), modifier=Modifier.fillMaxWidth()) {
                    Button(onClick={ (LocalContextHolder.current as? MainActivity)?.sharePdf(person,captain,signed)},modifier=Modifier.weight(1f)){Text("PDF / Mail")}
                    Button(onClick={validated=true},enabled=!validated&&signed&&captain.isNotBlank(),modifier=Modifier.weight(1f)){Text(if(validated)"Validé" else "VALIDATION DÉFINITIVE")}
                }
                if(validated) Text("🔒 Feuille définitivement validée et verrouillée.", color=Color(0xFFB71C1C), fontWeight=FontWeight.Bold, modifier=Modifier.padding(top=8.dp))
            }
        }
        if(showSignature) AlertDialog(onDismissRequest={showSignature=false},title={Text("Signature électronique")},text={Text("Dans cette première version, confirmez la signature pour enregistrer l'accord. Une signature graphique pourra être ajoutée ensuite.")},confirmButton={Button(onClick={signed=true;showSignature=false}){Text("Signer")}},dismissButton={TextButton(onClick={showSignature=false}){Text("Annuler")}})
    }
}

// Simple composition-local bridge to the Activity.
object LocalContextHolder { val current: android.content.Context? @Composable get() = androidx.compose.ui.platform.LocalContext.current }
