package com.example.tempsderepos

import android.content.Intent
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.Environment
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

private const val DAYS = 8 // Friday -> Thursday + Friday suivant
private const val SLOTS = 96
private const val SLOT_MINUTES = 15

private fun slotLabel(i: Int): String {
    val m = i * SLOT_MINUTES
    return String.format(Locale.FRANCE, "%02d:%02d", (8 + m / 60) % 24, m % 60)
}

private fun dayNames() = listOf("Vendredi", "Samedi", "Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi suivant")

private fun fridayStart(cal: Calendar): Calendar {
    val c = cal.clone() as Calendar
    c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
    val delta = (c.get(Calendar.DAY_OF_WEEK) - Calendar.FRIDAY + 7) % 7
    c.add(Calendar.DAY_OF_MONTH, -delta)
    return c
}

private data class WeekInfo(val number: Int, val year: Int, val start: Calendar) {
    val fileBase: String get() = "Semaine_${number}_${year}"
}

private fun weekInfo(date: Calendar = Calendar.getInstance()): WeekInfo {
    val start = fridayStart(date)
    // The year is determined by the first day (Friday). Week 1 is the Friday
    // on or immediately after January 1st; the Friday before it belongs to the previous year.
    val year = start.get(Calendar.YEAR)
    val first = Calendar.getInstance().apply {
        clear()
        set(year, Calendar.JANUARY, 1, 0, 0, 0)
        val d = (Calendar.FRIDAY - get(Calendar.DAY_OF_WEEK) + 7) % 7
        add(Calendar.DAY_OF_MONTH, d)
    }
    val number = (((start.timeInMillis - first.timeInMillis) / (7L * 24 * 60 * 60 * 1000L)).toInt() + 1).coerceAtLeast(1)
    return WeekInfo(number, year, start)
}

private fun formatDuration(minutes: Int): String = String.format(Locale.FRANCE, "%02dh%02d", minutes / 60, minutes % 60)

private data class Summary(val worked: Int, val restFrom13: Int, val worked24: Int, val rest24: Int)

private fun computeSummary(selected: Set<Pair<Int, Int>>, dayIndex: Int): Summary {
    fun workedFor(d: Int): Int = selected.count { it.first == d } * SLOT_MINUTES

    // For the selected day, the 96 cells represent the full 24 h period 08:00 -> 08:00.
    val worked = workedFor(dayIndex)
    val worked24 = worked

    // Build work intervals on this 24h cycle. A rest interval is a gap between
    // two work cells; only complete gaps >= 2h are eligible.
    val indices = (0 until SLOTS).filter { selected.contains(dayIndex to it) }
    val rests = mutableListOf<Pair<Int, Int>>() // [start slot, end slot), in 15-min slots
    if (indices.isNotEmpty()) {
        var previousEnd = indices.first()
        for (idx in indices.drop(1)) {
            if (idx > previousEnd) rests += previousEnd to idx
            previousEnd = idx
        }
        // Do not invent a rest after the last work cell; the planning day ends at 08:00.
    }
    var rest13 = 0
    var rest24 = 0
    for ((start, end) in rests) {
        val duration = (end - start) * SLOT_MINUTES
        if (duration >= 120) {
            rest24 += duration
            val from13Slot = 20 // 13:00 is 5h after 08:00
            val overlapStart = max(start, from13Slot)
            if (end > overlapStart) rest13 += (end - overlapStart) * SLOT_MINUTES
        }
    }
    return Summary(worked, rest13, worked24, rest24)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TempsDeReposApp() }
    }

    private fun makePdf(person: String, captain: String, signed: Boolean, week: WeekInfo, selected: Set<Pair<Int, Int>>): File {
        val dir = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)!!
        val file = File(dir, "${week.fileBase}.pdf")
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
        val c = page.canvas
        val p = Paint().apply { color = android.graphics.Color.BLACK; textSize = 18f; isAntiAlias = true }
        c.drawText("TEMPS DE REPOS", 40f, 50f, p)
        p.textSize = 12f
        c.drawText("Personne : $person", 40f, 80f, p)
        c.drawText("Semaine ${week.number} / ${week.year} — vendredi → jeudi", 40f, 100f, p)
        c.drawText("Fichier : ${week.fileBase}.pdf", 40f, 120f, p)
        c.drawText("Validation définitive : ${if (signed) "OUI" else "NON"}", 40f, 140f, p)
        c.drawText("Capitaine : $captain", 40f, 160f, p)
        var y = 195f
        dayNames().forEachIndexed { d, name ->
            val s = computeSummary(selected, d)
            c.drawText("$name : travaillé ${formatDuration(s.worked)} — repos ≥2h ${formatDuration(s.rest24)}", 40f, y, p)
            y += 22f
        }
        c.drawText("Grille : pas de saisie automatique — une case sélectionnée = temps travaillé.", 40f, y + 20f, p)
        c.drawText("Créé le : ${SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE).format(Calendar.getInstance().time)}", 40f, y + 42f, p)
        doc.finishPage(page)
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file
    }

    fun sharePdf(person: String, captain: String, signed: Boolean, week: WeekInfo, selected: Set<Pair<Int, Int>>) {
        val f = makePdf(person, captain, signed, week, selected)
        val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }, "Envoyer le rapport PDF"))
    }
}

@Composable
fun TempsDeReposApp() {
    val context = LocalContext.current
    val activity = context as? MainActivity
    val prefs = remember { context.getSharedPreferences("tempsderepos", 0) }

    var person by remember { mutableStateOf(prefs.getString("person", "") ?: "") }
    var captain by remember { mutableStateOf(prefs.getString("captain", "") ?: "") }
    var day by remember { mutableStateOf(prefs.getInt("day", 0).coerceIn(0, DAYS - 1)) }
    var validated by remember { mutableStateOf(prefs.getBoolean("validated", false)) }
    var signed by remember { mutableStateOf(prefs.getBoolean("signed", false)) }
    var showSignature by remember { mutableStateOf(false) }
    var selected by remember {
        mutableStateOf(buildSet {
            val raw = prefs.getString("selected", "") ?: ""
            raw.split(',').forEach { token ->
                val a = token.split(':')
                if (a.size == 2) {
                    val d = a[0].toIntOrNull(); val s = a[1].toIntOrNull()
                    if (d != null && s != null && d in 0 until DAYS && s in 0 until SLOTS) add(d to s)
                }
            }
        })
    }
    var anchor by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    val names = dayNames()
    val week = remember { weekInfo() }
    val summary = computeSummary(selected, day)

    fun save() {
        prefs.edit()
            .putString("person", person)
            .putString("captain", captain)
            .putInt("day", day)
            .putBoolean("validated", validated)
            .putBoolean("signed", signed)
            .putString("selected", selected.sortedWith(compareBy<Pair<Int, Int>> { it.first }.thenBy { it.second }).joinToString(",") { "${it.first}:${it.second}" })
            .apply()
    }

    MaterialTheme {
        Column(Modifier.fillMaxSize().background(Color(0xFFF5F7FA))) {
            Row(Modifier.fillMaxWidth().background(Color.White).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("TEMPS DE REPOS", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Semaine ${week.number} / ${week.year} — vendredi → jeudi", color = Color.Gray, fontSize = 12.sp)
                }
                Text("Données conservées", fontSize = 11.sp, color = Color(0xFF2E7D32))
            }

            Column(Modifier.padding(12.dp)) {
                OutlinedTextField(value = person, onValueChange = { if (!validated) { person = it; save() } }, label = { Text("Nom de la personne") }, modifier = Modifier.fillMaxWidth(), enabled = !validated)
                Spacer(Modifier.height(8.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Semaine : ", fontWeight = FontWeight.Bold)
                    Text("${week.number} / ${week.year}  •  ${week.fileBase}.pdf")
                }
                Text("La semaine commence toujours le vendredi. L'année du fichier est celle de ce vendredi.", fontSize = 11.sp, color = Color.Gray)
                Spacer(Modifier.height(8.dp))

                Row(Modifier.horizontalScroll(rememberScrollState())) {
                    names.forEachIndexed { i, d ->
                        FilterChip(selected = day == i, onClick = { if (!validated) { day = i; anchor = null; save() } }, label = { Text(d) }, modifier = Modifier.padding(end = 5.dp))
                    }
                }

                Spacer(Modifier.height(10.dp))
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(10.dp)) {
                        Text("${names[day]} — 08:00 → 08:00", fontWeight = FontWeight.Bold)
                        Text("Touchez une case = temps travaillé. Appui long = sélection de plage depuis la dernière case sélectionnée.", fontSize = 12.sp, color = Color.Gray)
                        Spacer(Modifier.height(8.dp))

                        Row(Modifier.horizontalScroll(rememberScrollState()).padding(bottom = 8.dp)) {
                            (0 until SLOTS).forEach { i ->
                                val key = day to i
                                val isSelected = selected.contains(key)
                                Box(
                                    Modifier.width(52.dp).height(58.dp).padding(2.dp).clip(RoundedCornerShape(4.dp))
                                        .background(if (isSelected) Color(0xFF90CAF9) else Color.White)
                                        .border(1.dp, Color.LightGray, RoundedCornerShape(4.dp))
                                        .pointerInput(validated, anchor, selected, day) {
                                            detectTapGestures(
                                                onTap = {
                                                    if (!validated) {
                                                        selected = selected.toMutableSet().apply { if (!remove(key)) add(key) }
                                                        anchor = key
                                                        save()
                                                    }
                                                },
                                                onLongPress = {
                                                    if (!validated) {
                                                        val a = anchor ?: key
                                                        if (a.first == day) {
                                                            val lo = min(a.second, i); val hi = max(a.second, i)
                                                            selected = selected.toMutableSet().apply { for (s in lo..hi) add(day to s) }
                                                        } else {
                                                            // Long press from a different day: select from the anchor cell through the new cell
                                                            // across the Friday-start week, including the extra Friday tab.
                                                            val orderedA = a.first * SLOTS + a.second
                                                            val orderedB = day * SLOTS + i
                                                            val lo = min(orderedA, orderedB); val hi = max(orderedA, orderedB)
                                                            selected = selected.toMutableSet().apply { for (v in lo..hi) add((v / SLOTS) to (v % SLOTS)) }
                                                        }
                                                        anchor = key
                                                        save()
                                                    }
                                                }
                                            )
                                        },
                                    contentAlignment = Alignment.Center
                                ) { Text(slotLabel(i), fontSize = 9.sp) }
                            }
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(10.dp)) {
                        Text("Récapitulatif — $day", fontWeight = FontWeight.Bold)
                        Text("Heures travaillées depuis 08h00 : ${formatDuration(summary.worked)}", fontWeight = FontWeight.SemiBold)
                        Text("Heures de repos depuis 08h00 : ${formatDuration(summary.restFrom13)}", fontWeight = FontWeight.SemiBold)
                        Text("(repos comptabilisé uniquement si la période de repos complète dure ≥ 2h et seulement à partir de 13h00)", fontSize = 10.sp, color = Color.Gray)
                        Spacer(Modifier.height(4.dp))
                        Text("Heures travaillées sur les 24 dernières heures : ${formatDuration(summary.worked24)}", fontWeight = FontWeight.SemiBold)
                        Text("Heures de repos sur les 24 dernières heures : ${formatDuration(summary.rest24)}", fontWeight = FontWeight.SemiBold)
                        Text("(repos ≥ 2h)", fontSize = 10.sp, color = Color.Gray)
                    }
                }

                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Signature utilisateur : ", fontWeight = FontWeight.Bold)
                    Text(if (signed) "SIGNÉE" else "Non signée", color = if (signed) Color(0xFF2E7D32) else Color.Gray)
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { showSignature = true }, enabled = !validated) { Text("Signer") }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = captain, onValueChange = { if (!validated) { captain = it; save() } }, label = { Text("Nom du capitaine") }, modifier = Modifier.fillMaxWidth(), enabled = !validated)
                Spacer(Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(onClick = { activity?.sharePdf(person, captain, signed, week, selected) }, modifier = Modifier.weight(1f)) { Text("PDF / Mail") }
                    Button(onClick = { validated = true; save() }, enabled = !validated && signed && captain.isNotBlank(), modifier = Modifier.weight(1f)) { Text("VALIDATION DÉFINITIVE") }
                }
                if (validated) Text("🔒 Feuille définitivement validée et verrouillée.", color = Color(0xFFB71C1C), fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
            }
        }

        if (showSignature) {
            AlertDialog(onDismissRequest = { showSignature = false }, title = { Text("Signature électronique") }, text = { Text("Confirmez la signature pour enregistrer l'accord.") },
                confirmButton = { Button(onClick = { signed = true; showSignature = false; save() }) { Text("Signer") } },
                dismissButton = { TextButton(onClick = { showSignature = false }) { Text("Annuler") } })
        }
    }
}
