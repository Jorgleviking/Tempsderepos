package com.example.tempsderepos

import android.content.Intent
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.Environment
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.max

private const val DAYS = 8 // Friday -> Thursday + following Friday
private const val WORK_DAYS = 7
private const val SLOTS = 96
private const val SLOT_MINUTES = 15

private fun dayNames() = listOf("Vendredi", "Samedi", "Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi +1")

data class WeekInfo(val number: Int, val year: Int, val firstFriday: Calendar, val fileBase: String)

private fun weekInfo(date: Calendar = Calendar.getInstance()): WeekInfo {
    val d = date.clone() as Calendar
    d.set(Calendar.HOUR_OF_DAY, 0); d.set(Calendar.MINUTE, 0); d.set(Calendar.SECOND, 0); d.set(Calendar.MILLISECOND, 0)
    val year = d.get(Calendar.YEAR)
    val first = Calendar.getInstance().apply {
        clear(); set(year, Calendar.JANUARY, 1)
        while (get(Calendar.DAY_OF_WEEK) != Calendar.FRIDAY) add(Calendar.DAY_OF_MONTH, 1)
    }
    val actualFirst = if (d.before(first)) Calendar.getInstance().apply {
        clear(); set(year - 1, Calendar.JANUARY, 1)
        while (get(Calendar.DAY_OF_WEEK) != Calendar.FRIDAY) add(Calendar.DAY_OF_MONTH, 1)
        // first Friday of previous year
    } else first
    val diffDays = ((d.timeInMillis - actualFirst.timeInMillis) / 86_400_000L).toInt()
    val n = diffDays / 7 + 1
    val y = actualFirst.get(Calendar.YEAR)
    return WeekInfo(n, y, actualFirst, "Semaine_${n.toString().padStart(2, '0')}_$y")
}

private fun formatDuration(minutes: Int): String = "${minutes / 60}h${(minutes % 60).toString().padStart(2, '0')}"

private data class Summary(val worked: Int, val restFrom13: Int, val worked24: Int, val rest24: Int)

private fun computeSummary(selected: Set<Pair<Int, Int>>, day: Int): Summary {
    val indices = (0 until SLOTS).filter { selected.contains(day to it) }
    val worked = indices.size * SLOT_MINUTES
    // La période de repos disponible démarre à sa valeur maximale de 19 h.
    // Elle diminue au fur et à mesure que des heures de travail sont enregistrées.
    val maxRestMinutes = 19 * 60
    if (indices.isEmpty()) return Summary(0, maxRestMinutes, 0, maxRestMinutes)
    val rests = mutableListOf<Pair<Int, Int>>()
    var prev = indices.first()
    for (i in indices.drop(1)) {
        if (i > prev) rests += prev to i
        prev = i
    }
    var rest24 = 0
    var rest13 = 0
    for ((start, end) in rests) {
        val duration = (end - start) * SLOT_MINUTES
        if (duration >= 120) {
            rest24 += duration
            val start13 = 20 // 13:00, five hours after 08:00
            val overlapStart = max(start, start13)
            if (end > overlapStart) rest13 += (end - overlapStart) * SLOT_MINUTES
        }
    }
    // Le repos disponible est calculé à partir de 13:00 : 19 h maximum.
    val workedFrom13 = indices.count { it >= 20 } * SLOT_MINUTES
    val availableRest = max(0, maxRestMinutes - workedFrom13)
    return Summary(worked, rest13, worked, availableRest)
}

private data class RestPeriod(val start: Int, val end: Int) {
    val minutes: Int get() = (end - start) * SLOT_MINUTES
}

private fun largestRestPeriods(selected: Set<Pair<Int, Int>>, day: Int): List<RestPeriod> {
    // Les périodes de repos réglementaires commencent à 13:00 et se poursuivent
    // jusqu'à 08:00 le lendemain. 08:00 → 13:00 n'entre donc jamais dans ce calcul.
    val firstRestSlot = 20 // 13:00, cinq heures après 08:00
    val periods = mutableListOf<RestPeriod>()
    var start = -1
    for (i in firstRestSlot until SLOTS) {
        val worked = selected.contains(day to i)
        if (!worked && start < 0) start = i
        if ((worked || i == SLOTS - 1) && start >= 0) {
            val end = if (worked) i else SLOTS
            if (end > start) periods += RestPeriod(start, end)
            start = -1
        }
    }
    return periods.sortedByDescending { it.minutes }.take(2)
}

private fun formatSlotTime(slot: Int): String {
    val minutes = slot * SLOT_MINUTES
    return String.format(Locale.FRANCE, "%02d:%02d", (8 + minutes / 60) % 24, minutes % 60)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TempsDeReposApp() }
    }

    fun sharePdf(person: String, captain: String, signed: Boolean, week: WeekInfo, selected: Set<Pair<Int, Int>>) {
        val dir = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)!!
        val file = File(dir, "${week.fileBase}.pdf")
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
        val c = page.canvas
        val p = Paint().apply { color = android.graphics.Color.BLACK; textSize = 15f; isAntiAlias = true }
        c.drawText("TEMPS DE REPOS", 40f, 45f, p)
        p.textSize = 11f
        c.drawText("Personne : $person", 40f, 70f, p)
        c.drawText("Semaine ${week.number} / ${week.year} — vendredi → jeudi", 40f, 90f, p)
        c.drawText("Nom du fichier : ${week.fileBase}.pdf", 40f, 108f, p)
        c.drawText("Validation définitive : ${if (signed) "OUI" else "NON"}", 40f, 126f, p)
        c.drawText("Capitaine : $captain", 40f, 144f, p)
        var y = 178f
        dayNames().forEachIndexed { d, name ->
            val s = computeSummary(selected, d)
            val rests = largestRestPeriods(selected, d)
            c.drawText("$name : travail 08h00 → 08h00 = ${formatDuration(s.worked)}", 40f, y, p)
            y += 18f
            rests.forEachIndexed { i, r ->
                c.drawText("  Repos ${i + 1} : ${formatSlotTime(r.start)} → ${formatSlotTime(r.end)} (${formatDuration(r.minutes)})", 40f, y, p)
                y += 16f
            }
            y += 3f
        }
        c.drawText("Une case sélectionnée = temps travaillé. Intervalles de 15 minutes.", 40f, y + 10f, p)
        doc.finishPage(page)
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }, "Envoyer le rapport PDF"))
    }
}

@Composable
fun TempsDeReposApp() {
    val context = LocalContext.current
    val activity = context as? MainActivity
    val prefs = remember { context.getSharedPreferences("tempsderepos", 0) }
    val names = dayNames()
    val week = remember { weekInfo() }

    var person by remember { mutableStateOf(prefs.getString("person", "") ?: "") }
    var captain by remember { mutableStateOf(prefs.getString("captain", "") ?: "") }
    var day by remember { mutableStateOf(prefs.getInt("day", 0).coerceIn(0, DAYS - 1)) }
    var validated by remember { mutableStateOf(prefs.getBoolean("validated", false)) }
    var signed by remember { mutableStateOf(prefs.getBoolean("signed", false)) }
    var showSignature by remember { mutableStateOf(false) }
    var selected by remember {
        mutableStateOf(buildSet {
            val raw = prefs.getString("selected", "") ?: ""
            raw.split(',').filter { it.isNotBlank() }.forEach { token ->
                val a = token.split(':')
                if (a.size == 2) {
                    val d = a[0].toIntOrNull(); val s = a[1].toIntOrNull()
                    if (d != null && s != null && d in 0 until DAYS && s in 0 until SLOTS) add(d to s)
                }
            }
        })
    }
    var anchor by remember { mutableStateOf<Pair<Int, Int>?>(null) }

    fun save() {
        prefs.edit()
            .putString("person", person)
            .putString("captain", captain)
            .putInt("day", day)
            .putBoolean("validated", validated)
            .putBoolean("signed", signed)
            .putString("selected", selected.sortedWith(compareBy<Pair<Int, Int>> { it.first }.thenBy { it.second }).joinToString(",") { "${it.first}:${it.second}" })
            .apply()
    }

    val summary = computeSummary(selected, day)
    val slots = (0 until SLOTS).map { i ->
        val startMin = i * SLOT_MINUTES
        val endMin = startMin + SLOT_MINUTES
        val startText = String.format(Locale.FRANCE, "%02d:%02d", (8 + startMin / 60) % 24, startMin % 60)
        val endText = String.format(Locale.FRANCE, "%02d:%02d", (8 + endMin / 60) % 24, endMin % 60)
        "$startText → $endText"
    }

    MaterialTheme {
        Column(Modifier.fillMaxSize().background(Color(0xFFF5F7FA))) {
            Row(Modifier.fillMaxWidth().background(Color.White).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("TEMPS DE REPOS", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Semaine ${week.number} / ${week.year} — vendredi → jeudi", color = Color.Gray, fontSize = 12.sp)
                }
                Text("Données conservées", fontSize = 11.sp, color = Color(0xFF2E7D32))
            }

            Column(Modifier.padding(12.dp).verticalScroll(rememberScrollState())) {
                OutlinedTextField(value = person, onValueChange = { if (!validated) { person = it; save() } }, label = { Text("Nom de la personne") }, modifier = Modifier.fillMaxWidth(), enabled = !validated)
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Semaine : ", fontWeight = FontWeight.Bold)
                    Text("${week.number} / ${week.year}")
                }
                Text("Début : ${SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE).format(week.firstFriday.time)} — l'année du fichier est celle du vendredi de début.", fontSize = 11.sp, color = Color.Gray)
                Text("Fichier : ${week.fileBase}.pdf", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(7.dp))

                Row(Modifier.horizontalScroll(rememberScrollState())) {
                    names.forEachIndexed { i, name ->
                        FilterChip(selected = day == i, onClick = { if (!validated) { day = i; anchor = null; save() } }, label = { Text(name) }, modifier = Modifier.padding(end = 5.dp))
                    }
                }
                Spacer(Modifier.height(8.dp))

                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(10.dp)) {
                        Text("${names[day]} — 08:00 → 08:00", fontWeight = FontWeight.Bold)
                        Text("Touchez le début puis la fin de chaque période. Unité : 15 minutes.", fontSize = 12.sp, color = Color.Gray)
                        Spacer(Modifier.height(8.dp))
                        // Fenêtre de 6 heures environ. Le contenu complet reste déplaçable
                        // horizontalement pour parcourir les 24 heures de la plage 08:00 → 08:00.
                        val timelineScroll = rememberScrollState()
                        val slotWidth = 16.dp
                        val timelineWidth = slotWidth * 96
                        Column(Modifier.fillMaxWidth()) {
                            Box(Modifier.fillMaxWidth().horizontalScroll(timelineScroll)) {
                                Column(Modifier.width(timelineWidth)) {
                                    // Une heure = 4 cases de 15 minutes.
                                    // Les heures rondes sont matérialisées par un trait vertical gras.
                                    Row(Modifier.fillMaxWidth().height(34.dp)) {
                                        (0 until 96 step 4).forEach { h ->
                                            Box(
                                                Modifier.width(slotWidth * 4),
                                                contentAlignment = Alignment.CenterStart
                                            ) {
                                                Text(
                                                    formatSlotTime(h),
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                    }
                                    Row(Modifier.fillMaxWidth().height(82.dp)) {
                                        slots.forEachIndexed { i, _ ->
                                            val key = day to i
                                            val isSelected = selected.contains(key)
                                            Box(
                                                Modifier.width(slotWidth).fillMaxHeight()
                                                    .background(if (isSelected) Color(0xFF3D8FE8) else Color.White)
                                                    .border(
                                                        1.dp,
                                                        if (isSelected) Color(0xFF2D79D1) else Color(0xFFB8C4D0)
                                                    )
                                                    .pointerInput(validated, anchor, selected, day) {
                                                        detectTapGestures(onTap = {
                                                            if (!validated) {
                                                                val a = anchor
                                                                if (a == null) {
                                                                    // Premier appui : mémorise uniquement le début de la période.
                                                                    anchor = key
                                                                } else {
                                                                    val lo = minOf(a.second, i)
                                                                    val hi = max(a.second, i)
                                                                    // Le premier appui fixe le début et le second la fin.
                                                                    // La fin est une borne : 16:15 puis 16:45 sélectionne
                                                                    // 16:15-16:30 et 16:30-16:45, soit 30 minutes.
                                                                    val next = selected.toMutableSet()
                                                                    for (x in lo until hi) next.add(day to x)
                                                                    // Si la même case est touchée deux fois, sélectionner un quart d'heure.
                                                                    if (lo == hi) next.add(day to lo)
                                                                    selected = next
                                                                    anchor = null
                                                                }
                                                                save()
                                                            }
                                                        })
                                                    }
                                            ) {
                                                // Trait gras au début de chaque heure.
                                                if (i % 4 == 0) {
                                                    Box(
                                                        Modifier
                                                            .width(3.dp)
                                                            .fillMaxHeight()
                                                            .background(Color(0xFF17233F))
                                                    )
                                                }
                                                // Trait gras à la fin de la plage 08:00 → 08:00.
                                                if (i == 95) {
                                                    Box(
                                                        Modifier
                                                            .width(3.dp)
                                                            .fillMaxHeight()
                                                            .align(Alignment.CenterEnd)
                                                            .background(Color(0xFF17233F))
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            Spacer(Modifier.height(6.dp))
                            Text("Faites glisser horizontalement pour déplacer l’échelle", modifier = Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontSize = 12.sp, color = Color.Gray)
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))

                // Récapitulatif simplifié : total du travail sur 08:00 → 08:00
                // et les deux plus grandes périodes de repos.
                val topRestPeriods = largestRestPeriods(selected, day)

                Card(
                    Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF0F7FF))
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                            Box(
                                Modifier.size(54.dp).clip(RoundedCornerShape(18.dp)).background(Color(0xFF3F73C9)),
                                contentAlignment = Alignment.Center
                            ) { Text("◷", color = Color.White, fontSize = 30.sp) }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text("RÉCAPITULATIF", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF14245B))
                                Text(names[day], fontSize = 14.sp, color = Color(0xFF49698D))
                            }
                            Box(
                                Modifier.clip(RoundedCornerShape(18.dp))
                                    .background(Color(0xFFD6E6FF))
                                    .padding(horizontal = 14.dp, vertical = 8.dp)
                            ) {
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(formatDuration(summary.worked), fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF14245B))
                                    Text("TRAVAIL", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF28558E))
                                }
                            }
                        }

                        Spacer(Modifier.height(14.dp))
                        Text("Temps de travail", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color(0xFF14245B))
                        Text("Total sur 08:00 → 08:00", fontSize = 12.sp, color = Color(0xFF49698D))
                        Spacer(Modifier.height(8.dp))
                        Box(
                            Modifier.fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color.White)
                                .padding(vertical = 14.dp, horizontal = 16.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text("Somme des heures travaillées", fontSize = 14.sp, color = Color(0xFF49698D))
                                Text(formatDuration(summary.worked), fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF14245B))
                            }
                        }

                        Spacer(Modifier.height(16.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.size(54.dp).clip(RoundedCornerShape(18.dp)).background(Color(0xFF239447)),
                                contentAlignment = Alignment.Center
                            ) { Text("⌛", color = Color.White, fontSize = 27.sp) }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Heures de repos", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF125E3A))
                                Text("Les 2 plus grandes périodes sur 13:00 → 08:00", fontSize = 12.sp, color = Color(0xFF3F745D))
                            }
                        }

                        Spacer(Modifier.height(9.dp))
                        if (topRestPeriods.isEmpty()) {
                            Box(
                                Modifier.fillMaxWidth()
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(Color(0xFFE9F8EF))
                                    .padding(16.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("Aucune période de repos", color = Color(0xFF16613F), fontSize = 13.sp)
                            }
                        } else {
                            topRestPeriods.forEachIndexed { index, rest ->
                                val startText = formatSlotTime(rest.start)
                                val endText = formatSlotTime(rest.end)
                                Card(
                                    Modifier.fillMaxWidth().padding(bottom = if (index == topRestPeriods.lastIndex) 0.dp else 8.dp),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFFE9F8EF))
                                ) {
                                    Row(
                                        Modifier.fillMaxWidth().padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(Modifier.weight(1f)) {
                                            Text("Repos ${index + 1}", fontWeight = FontWeight.Bold, color = Color(0xFF16613F))
                                            Text("$startText → $endText", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF14245B))
                                        }
                                        Text(formatDuration(rest.minutes), fontSize = 21.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF125E3A))
                                    }
                                }
                            }
                        }
                    }
                }


                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Signature utilisateur : ", fontWeight = FontWeight.Bold)
                    Text(if (signed) "SIGNÉE" else "Non signée", color = if (signed) Color(0xFF2E7D32) else Color.Gray)
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { showSignature = true }, enabled = !validated) { Text("Signer") }
                }
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(value = captain, onValueChange = { if (!validated) { captain = it; save() } }, label = { Text("Nom du capitaine") }, modifier = Modifier.fillMaxWidth(), enabled = !validated)
                Spacer(Modifier.height(7.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(onClick = { activity?.sharePdf(person, captain, signed, week, selected) }, modifier = Modifier.weight(1f)) { Text("PDF / Mail") }
                    Button(onClick = { validated = true; save() }, enabled = !validated && signed && captain.isNotBlank(), modifier = Modifier.weight(1f)) { Text("VALIDATION DÉFINITIVE") }
                }
                if (validated) Text("🔒 Feuille définitivement validée et verrouillée.", color = Color(0xFFB71C1C), fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
            }
        }

        if (showSignature) AlertDialog(
            onDismissRequest = { showSignature = false },
            title = { Text("Signature électronique") },
            text = { Text("Confirmez la signature pour enregistrer l'accord.") },
            confirmButton = { Button(onClick = { signed = true; showSignature = false; save() }) { Text("Signer") } },
            dismissButton = { TextButton(onClick = { showSignature = false }) { Text("Annuler") } }
        )
    }
}
